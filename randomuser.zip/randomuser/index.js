const rq= require('electron-require');
const main= rq.remote('./main.js');