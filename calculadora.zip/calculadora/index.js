//Agrega al codigo (un enlace) al main.js
const rq= require('electron-require');
const main= rq.remote('./main.js');
var botonesNumero= ["btn00","btn01","btn02","btn03","btn04","btn05","btn06","btn07","btn08","btn09"];

var botonesOperador= ["btnSumar","btnRestar","btnMultiplicar","btnDividir"];
var operador="";
function numeros(){
var num=String(this.value)
 if (operador==""){ //validando el operador1
 	var va= document.getElementByID("operador1").value;
 	if(va=="0"){
 		document.getElementByID("operador1").value="";
 	}
 	document.getElementByID("operador1").value+=num;
 } else{
 	var va= document.getElementByID("operador2").value;
 	if(va=="0"){
 		document.getElementByID("operador2").value="";
 	}
 	document.getElementByID("operador2").value+=num;
 }
}
function operadores(){
 operador= String(this.value);//+,-,*,/
}
function igual(){
var valor1=document.getElementByID("operador1").value;
var valor2=document.getElementByID("operador2").value;
document.getElementByID("resultado").value=eval(valor1+operador+valor2);
}
function borrar(){
	document.getElementByID("operador1").value= "0";
	document.getElementByID("operador2").value= "0";
	document.getElementByID("resultado").value= "0";
	operador="";
}
//Asignacion de eventos a los botones de numeros
for (var i=0;i<botonesOperador.length;i++){
	document.getElementByID(botonesOperador [i]).addEventListener('click',numeros);
}
//Asignacion de eventos para los botones de operador
for (var i=0;i<botonesNumero.length;i++){
	document.getElementByID(botonesNumero [i]).addEventListener('click',Operadores);
}
document.getElementByID("btnIgual").addEventListener('click',igual)
document.getElementByID("btnBorrar").addEventListener('click',borrar)
